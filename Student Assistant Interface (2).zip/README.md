
  # Student Assistant Interface

  This is a code bundle for Student Assistant Interface. The original project is available at https://www.figma.com/design/z9YVDSuMfBRclK381lPmfq/Student-Assistant-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
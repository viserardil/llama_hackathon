import { useState } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { CVScore } from './components/CVScore';
import { ChatAssistant } from './components/ChatAssistant';
import { GitHubProfile } from './components/GitHubProfile';

export default function App() {
  const [showWelcome, setShowWelcome] = useState(true);
  const [activeView, setActiveView] = useState('cv');

  if (showWelcome) {
    return <WelcomeScreen onEnter={() => setShowWelcome(false)} />;
  }

  const renderView = () => {
    switch (activeView) {
      case 'cv':
        return <CVScore />;
      case 'chat':
        return <ChatAssistant />;
      case 'github':
        return <GitHubProfile />;
      default:
        return <CVScore />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar activeView={activeView} onNavigate={setActiveView} />
        <main className="flex-1 p-6 lg:p-8">
          {renderView()}
        </main>
      </div>
    </div>
  );
}

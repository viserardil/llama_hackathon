import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { 
  FileText, 
  Upload, 
  Award,
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  Briefcase,
  GraduationCap,
  Mail,
  Phone,
  Globe,
  Sparkles,
  Target,
  XCircle,
  File,
  X
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface CVAnalysis {
  overallScore: number;
  sections: {
    contactInfo: { score: number; present: string[]; missing: string[] };
    summary: { score: number; hasSection: boolean; wordCount: number };
    experience: { score: number; count: number; hasQuantifiableAchievements: boolean };
    education: { score: number; hasSection: boolean; institutions: number };
    skills: { score: number; count: number; categories: string[] };
    keywords: { score: number; matched: string[]; missing: string[] };
  };
  strengths: string[];
  improvements: string[];
  industryMatch: string;
}

export function CVScore() {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [analysis, setAnalysis] = useState<CVAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Mock CV analysis for demonstration
  const analyzeMockCV = () => {
    return {
      overallScore: 78,
      sections: {
        contactInfo: {
          score: 90,
          present: ['Email', 'Phone', 'LinkedIn'],
          missing: ['Portfolio Website'],
        },
        summary: {
          score: 70,
          hasSection: true,
          wordCount: 45,
        },
        experience: {
          score: 85,
          count: 3,
          hasQuantifiableAchievements: true,
        },
        education: {
          score: 95,
          hasSection: true,
          institutions: 2,
        },
        skills: {
          score: 75,
          count: 12,
          categories: ['Technical', 'Soft Skills', 'Languages'],
        },
        keywords: {
          score: 60,
          matched: ['JavaScript', 'React', 'Python', 'Teamwork', 'Leadership'],
          missing: ['TypeScript', 'Cloud Computing', 'CI/CD', 'Agile'],
        },
      },
      strengths: [
        'Strong quantifiable achievements in work experience',
        'Well-structured education section with relevant coursework',
        'Clear contact information with professional links',
        'Good mix of technical and soft skills',
      ],
      improvements: [
        'Add a portfolio website to showcase projects',
        'Include more industry-specific keywords (TypeScript, Cloud Computing)',
        'Expand professional summary to 50-80 words',
        'Add more recent certifications or professional development',
      ],
      industryMatch: 'Software Engineering',
    };
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type === 'application/pdf') {
      setUploadedFile(file);
    } else {
      alert('Please upload a PDF file');
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file && file.type === 'application/pdf') {
      setUploadedFile(file);
    } else {
      alert('Please upload a PDF file');
    }
  };

  const handleRemoveFile = () => {
    setUploadedFile(null);
    setAnalysis(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleAnalyze = () => {
    if (!uploadedFile) return;
    
    setLoading(true);
    // Simulate PDF processing and analysis
    setTimeout(() => {
      setAnalysis(analyzeMockCV());
      setLoading(false);
    }, 2000);
  };

  const getScoreGrade = (score: number) => {
    if (score >= 90) return { grade: 'A+', color: 'text-green-600', bgColor: 'bg-green-50' };
    if (score >= 80) return { grade: 'A', color: 'text-green-600', bgColor: 'bg-green-50' };
    if (score >= 70) return { grade: 'B', color: 'text-blue-600', bgColor: 'bg-blue-50' };
    if (score >= 60) return { grade: 'C', color: 'text-yellow-600', bgColor: 'bg-yellow-50' };
    return { grade: 'D', color: 'text-orange-600', bgColor: 'bg-orange-50' };
  };

  const scoreGrade = analysis ? getScoreGrade(analysis.overallScore) : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-1">CV/Resume Score</h1>
        <p className="text-gray-600">Analyze and optimize your resume for better job opportunities</p>
      </div>

      {/* Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Upload Your CV
          </CardTitle>
          <CardDescription>
            Upload your resume in PDF format for AI-powered analysis
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!uploadedFile ? (
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
                isDragging
                  ? 'border-blue-500 bg-blue-50'
                  : 'border-gray-300 hover:border-gray-400'
              }`}
            >
              <Upload className={`h-12 w-12 mx-auto mb-4 ${isDragging ? 'text-blue-500' : 'text-gray-400'}`} />
              <h3 className="text-gray-900 mb-2">
                {isDragging ? 'Drop your PDF here' : 'Drop your CV here'}
              </h3>
              <p className="text-gray-600 mb-4">or</p>
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="outline"
              >
                <FileText className="h-4 w-4 mr-2" />
                Browse Files
              </Button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                onChange={handleFileChange}
                className="hidden"
              />
              <p className="text-gray-500 mt-4">Accepted format: PDF (Max 10MB)</p>
            </div>
          ) : (
            <div className="border-2 border-green-300 rounded-lg p-6 bg-green-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center">
                    <File className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h4 className="text-gray-900">{uploadedFile.name}</h4>
                    <p className="text-gray-600">
                      {(uploadedFile.size / 1024).toFixed(2)} KB
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleRemoveFile}
                  className="text-gray-500 hover:text-red-600"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              <Separator className="my-4" />

              <Button
                onClick={handleAnalyze}
                disabled={loading}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                <Sparkles className="h-4 w-4 mr-2" />
                {loading ? 'Analyzing your CV...' : 'Analyze CV'}
              </Button>
            </div>
          )}

          <p className="text-gray-500">
            Note: This is a demo using AI analysis. Your data is not stored or shared.
          </p>
        </CardContent>
      </Card>

      {analysis && scoreGrade && (
        <>
          {/* Overall Score */}
          <Card className={scoreGrade.bgColor}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className={`h-6 w-6 ${scoreGrade.color}`} />
                Overall CV Score
              </CardTitle>
              <CardDescription>Based on industry standards and ATS optimization</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="flex items-baseline gap-2">
                    <span className={`text-gray-900 ${scoreGrade.color}`}>{analysis.overallScore}</span>
                    <span className="text-gray-600">/ 100</span>
                  </div>
                  <Badge className={`mt-2 ${scoreGrade.color}`} variant="outline">
                    Grade: {scoreGrade.grade}
                  </Badge>
                </div>
                <div className="text-right">
                  <p className="text-gray-600 mb-1">Industry Match</p>
                  <Badge variant="secondary">{analysis.industryMatch}</Badge>
                </div>
              </div>

              <Progress value={analysis.overallScore} className="h-3" />
            </CardContent>
          </Card>

          {/* Section Scores */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <span className="text-gray-900">Contact Info</span>
                  </div>
                  <Badge variant={analysis.sections.contactInfo.score >= 80 ? 'default' : 'secondary'}>
                    {analysis.sections.contactInfo.score}%
                  </Badge>
                </div>
                <Progress value={analysis.sections.contactInfo.score} className="h-2" />
                <div className="mt-3 space-y-1">
                  {analysis.sections.contactInfo.present.map((item) => (
                    <div key={item} className="flex items-center gap-2 text-green-600">
                      <CheckCircle2 className="h-3 w-3" />
                      <span>{item}</span>
                    </div>
                  ))}
                  {analysis.sections.contactInfo.missing.map((item) => (
                    <div key={item} className="flex items-center gap-2 text-orange-600">
                      <XCircle className="h-3 w-3" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-purple-600" />
                    <span className="text-gray-900">Summary</span>
                  </div>
                  <Badge variant={analysis.sections.summary.score >= 80 ? 'default' : 'secondary'}>
                    {analysis.sections.summary.score}%
                  </Badge>
                </div>
                <Progress value={analysis.sections.summary.score} className="h-2" />
                <div className="mt-3 text-gray-600">
                  <p>Word Count: {analysis.sections.summary.wordCount}</p>
                  <p className="text-gray-500">Ideal: 50-80 words</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Briefcase className="h-5 w-5 text-green-600" />
                    <span className="text-gray-900">Experience</span>
                  </div>
                  <Badge variant={analysis.sections.experience.score >= 80 ? 'default' : 'secondary'}>
                    {analysis.sections.experience.score}%
                  </Badge>
                </div>
                <Progress value={analysis.sections.experience.score} className="h-2" />
                <div className="mt-3 text-gray-600">
                  <p>{analysis.sections.experience.count} positions listed</p>
                  {analysis.sections.experience.hasQuantifiableAchievements && (
                    <div className="flex items-center gap-2 text-green-600 mt-1">
                      <CheckCircle2 className="h-3 w-3" />
                      <span>Quantifiable achievements</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <GraduationCap className="h-5 w-5 text-orange-600" />
                    <span className="text-gray-900">Education</span>
                  </div>
                  <Badge variant={analysis.sections.education.score >= 80 ? 'default' : 'secondary'}>
                    {analysis.sections.education.score}%
                  </Badge>
                </div>
                <Progress value={analysis.sections.education.score} className="h-2" />
                <div className="mt-3 text-gray-600">
                  <p>{analysis.sections.education.institutions} institutions</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-pink-600" />
                    <span className="text-gray-900">Skills</span>
                  </div>
                  <Badge variant={analysis.sections.skills.score >= 80 ? 'default' : 'secondary'}>
                    {analysis.sections.skills.score}%
                  </Badge>
                </div>
                <Progress value={analysis.sections.skills.score} className="h-2" />
                <div className="mt-3 text-gray-600">
                  <p>{analysis.sections.skills.count} skills listed</p>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {analysis.sections.skills.categories.map((cat) => (
                      <Badge key={cat} variant="outline">
                        {cat}
                      </Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-yellow-600" />
                    <span className="text-gray-900">Keywords</span>
                  </div>
                  <Badge variant={analysis.sections.keywords.score >= 80 ? 'default' : 'secondary'}>
                    {analysis.sections.keywords.score}%
                  </Badge>
                </div>
                <Progress value={analysis.sections.keywords.score} className="h-2" />
                <div className="mt-3 text-gray-600">
                  <p>{analysis.sections.keywords.matched.length} keywords matched</p>
                  <p className="text-gray-500">ATS optimization score</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Analysis */}
          <Tabs defaultValue="strengths" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="strengths">Strengths</TabsTrigger>
              <TabsTrigger value="improvements">Improvements</TabsTrigger>
              <TabsTrigger value="keywords">Keywords</TabsTrigger>
            </TabsList>

            <TabsContent value="strengths" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    What Your CV Does Well
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {analysis.strengths.map((strength, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-green-50 border border-green-200">
                      <CheckCircle2 className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
                      <p className="text-gray-700">{strength}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="improvements" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-orange-600" />
                    Areas for Improvement
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {analysis.improvements.map((improvement, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-orange-50 border border-orange-200">
                      <AlertCircle className="h-5 w-5 text-orange-600 mt-0.5 flex-shrink-0" />
                      <p className="text-gray-700">{improvement}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="keywords" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle2 className="h-5 w-5 text-green-600" />
                      Matched Keywords
                    </CardTitle>
                    <CardDescription>Keywords found in your CV</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {analysis.sections.keywords.matched.map((keyword) => (
                        <Badge key={keyword} className="bg-green-100 text-green-800 border-green-300">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <XCircle className="h-5 w-5 text-orange-600" />
                      Missing Keywords
                    </CardTitle>
                    <CardDescription>Consider adding these industry-relevant terms</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {analysis.sections.keywords.missing.map((keyword) => (
                        <Badge key={keyword} variant="outline" className="border-orange-300 text-orange-700">
                          {keyword}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>

          {/* Tips Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Professional Tips
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                  <h4 className="text-gray-900 mb-2">ATS Optimization</h4>
                  <p className="text-gray-600">Use standard section headers and avoid graphics or complex formatting to ensure your CV passes Applicant Tracking Systems.</p>
                </div>
                <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
                  <h4 className="text-gray-900 mb-2">Quantify Achievements</h4>
                  <p className="text-gray-600">Include numbers, percentages, and metrics to demonstrate the impact of your work (e.g., "Increased sales by 25%").</p>
                </div>
                <div className="p-4 rounded-lg bg-green-50 border border-green-200">
                  <h4 className="text-gray-900 mb-2">Tailor Your CV</h4>
                  <p className="text-gray-600">Customize your resume for each job application by incorporating keywords from the job description.</p>
                </div>
                <div className="p-4 rounded-lg bg-orange-50 border border-orange-200">
                  <h4 className="text-gray-900 mb-2">Keep it Concise</h4>
                  <p className="text-gray-600">Aim for 1-2 pages maximum. Use bullet points and clear, concise language to highlight key information.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { 
  Github, 
  Star, 
  GitFork, 
  Users, 
  Code, 
  TrendingUp,
  Award,
  Search,
  ExternalLink,
  Activity,
  Calendar
} from 'lucide-react';

interface GitHubStats {
  username: string;
  name: string;
  bio: string;
  avatar: string;
  followers: number;
  following: number;
  publicRepos: number;
  totalStars: number;
  totalForks: number;
  contributions: number;
  longestStreak: number;
  languages: { name: string; percentage: number; color: string }[];
  topRepos: { name: string; stars: number; forks: number; language: string }[];
}

export function GitHubProfile() {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [profileData, setProfileData] = useState<GitHubStats | null>(null);

  // Mock GitHub data for demonstration
  const mockGitHubData: GitHubStats = {
    username: 'alexjohnson',
    name: 'Alex Johnson',
    bio: 'Computer Science Student | Full Stack Developer | Open Source Enthusiast',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Alex',
    followers: 245,
    following: 180,
    publicRepos: 42,
    totalStars: 1247,
    totalForks: 189,
    contributions: 1583,
    longestStreak: 67,
    languages: [
      { name: 'JavaScript', percentage: 35, color: '#f1e05a' },
      { name: 'Python', percentage: 28, color: '#3572A5' },
      { name: 'TypeScript', percentage: 20, color: '#2b7489' },
      { name: 'Java', percentage: 12, color: '#b07219' },
      { name: 'Other', percentage: 5, color: '#8e8e8e' },
    ],
    topRepos: [
      { name: 'awesome-web-app', stars: 456, forks: 67, language: 'JavaScript' },
      { name: 'ml-learning-platform', stars: 312, forks: 45, language: 'Python' },
      { name: 'react-component-library', stars: 289, forks: 52, language: 'TypeScript' },
      { name: 'algorithm-visualizer', stars: 190, forks: 25, language: 'JavaScript' },
    ],
  };

  const calculateScore = (data: GitHubStats) => {
    // Scoring algorithm
    const repoScore = Math.min((data.publicRepos / 50) * 15, 15);
    const starScore = Math.min((data.totalStars / 1000) * 20, 20);
    const contributionScore = Math.min((data.contributions / 2000) * 25, 25);
    const followerScore = Math.min((data.followers / 200) * 10, 10);
    const streakScore = Math.min((data.longestStreak / 100) * 15, 15);
    const diversityScore = Math.min(data.languages.length * 3, 15);

    const totalScore = Math.round(
      repoScore + starScore + contributionScore + followerScore + streakScore + diversityScore
    );

    return {
      total: totalScore,
      breakdown: {
        repositories: Math.round(repoScore),
        stars: Math.round(starScore),
        contributions: Math.round(contributionScore),
        followers: Math.round(followerScore),
        streak: Math.round(streakScore),
        diversity: Math.round(diversityScore),
      }
    };
  };

  const handleSearch = () => {
    setLoading(true);
    // Simulate API call
    setTimeout(() => {
      setProfileData(mockGitHubData);
      setLoading(false);
    }, 1000);
  };

  const getScoreGrade = (score: number) => {
    if (score >= 90) return { grade: 'A+', color: 'text-green-600', bgColor: 'bg-green-50' };
    if (score >= 80) return { grade: 'A', color: 'text-green-600', bgColor: 'bg-green-50' };
    if (score >= 70) return { grade: 'B', color: 'text-blue-600', bgColor: 'bg-blue-50' };
    if (score >= 60) return { grade: 'C', color: 'text-yellow-600', bgColor: 'bg-yellow-50' };
    return { grade: 'D', color: 'text-orange-600', bgColor: 'bg-orange-50' };
  };

  const score = profileData ? calculateScore(profileData) : null;
  const scoreGrade = score ? getScoreGrade(score.total) : null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-gray-900 mb-1">GitHub Profile Score</h1>
        <p className="text-gray-600">Analyze and score your GitHub profile to showcase your coding skills</p>
      </div>

      {/* Search Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Github className="h-5 w-5" />
            Search GitHub Profile
          </CardTitle>
          <CardDescription>Enter a GitHub username to analyze their profile</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-3">
            <div className="flex-1">
              <Label htmlFor="username" className="sr-only">GitHub Username</Label>
              <Input
                id="username"
                placeholder="Enter GitHub username..."
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
            <Button onClick={handleSearch} disabled={loading}>
              <Search className="h-4 w-4 mr-2" />
              {loading ? 'Analyzing...' : 'Analyze'}
            </Button>
          </div>
          <p className="text-gray-500 mt-2">
            Note: This is a demo using mock data. In production, this would connect to the GitHub API.
          </p>
        </CardContent>
      </Card>

      {profileData && score && scoreGrade && (
        <>
          {/* Profile Overview & Score */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Profile Card */}
            <Card className="lg:col-span-1">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <img
                    src={profileData.avatar}
                    alt={profileData.name}
                    className="w-24 h-24 rounded-full mb-4"
                  />
                  <h3 className="text-gray-900 mb-1">{profileData.name}</h3>
                  <p className="text-gray-600 mb-2">@{profileData.username}</p>
                  <p className="text-gray-600 mb-4">{profileData.bio}</p>
                  <Button variant="outline" className="w-full" asChild>
                    <a href={`https://github.com/${profileData.username}`} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2" />
                      View on GitHub
                    </a>
                  </Button>
                </div>

                <Separator className="my-6" />

                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <p className="text-gray-600">Followers</p>
                    <p className="text-gray-900">{profileData.followers}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-600">Following</p>
                    <p className="text-gray-900">{profileData.following}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-600">Repos</p>
                    <p className="text-gray-900">{profileData.publicRepos}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-gray-600">Contributions</p>
                    <p className="text-gray-900">{profileData.contributions}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Overall Score */}
            <Card className={`lg:col-span-2 ${scoreGrade.bgColor}`}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className={`h-6 w-6 ${scoreGrade.color}`} />
                  Overall GitHub Score
                </CardTitle>
                <CardDescription>Based on activity, contributions, and community engagement</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className={`text-gray-900 ${scoreGrade.color}`}>{score.total}</span>
                      <span className="text-gray-600">/ 100</span>
                    </div>
                    <Badge className={`mt-2 ${scoreGrade.color}`} variant="outline">
                      Grade: {scoreGrade.grade}
                    </Badge>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-600 mb-1">Percentile</p>
                    <p className="text-gray-900">Top {100 - score.total}%</p>
                  </div>
                </div>

                <Progress value={score.total} className="h-3 mb-6" />

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-gray-600">Repositories</span>
                      <span className="text-gray-900">{score.breakdown.repositories}/15</span>
                    </div>
                    <Progress value={(score.breakdown.repositories / 15) * 100} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-gray-600">Stars Received</span>
                      <span className="text-gray-900">{score.breakdown.stars}/20</span>
                    </div>
                    <Progress value={(score.breakdown.stars / 20) * 100} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-gray-600">Contributions</span>
                      <span className="text-gray-900">{score.breakdown.contributions}/25</span>
                    </div>
                    <Progress value={(score.breakdown.contributions / 25) * 100} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-gray-600">Followers</span>
                      <span className="text-gray-900">{score.breakdown.followers}/10</span>
                    </div>
                    <Progress value={(score.breakdown.followers / 10) * 100} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-gray-600">Streak</span>
                      <span className="text-gray-900">{score.breakdown.streak}/15</span>
                    </div>
                    <Progress value={(score.breakdown.streak / 15) * 100} className="h-2" />
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-gray-600">Diversity</span>
                      <span className="text-gray-900">{score.breakdown.diversity}/15</span>
                    </div>
                    <Progress value={(score.breakdown.diversity / 15) * 100} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600">Total Stars</p>
                    <p className="text-gray-900 mt-1">{profileData.totalStars}</p>
                  </div>
                  <Star className="h-8 w-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600">Total Forks</p>
                    <p className="text-gray-900 mt-1">{profileData.totalForks}</p>
                  </div>
                  <GitFork className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600">Contributions</p>
                    <p className="text-gray-900 mt-1">{profileData.contributions}</p>
                  </div>
                  <Activity className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600">Longest Streak</p>
                    <p className="text-gray-900 mt-1">{profileData.longestStreak} days</p>
                  </div>
                  <Calendar className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Languages & Top Repos */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Languages */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Language Distribution
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {profileData.languages.map((lang) => (
                  <div key={lang.name}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: lang.color }}
                        />
                        <span className="text-gray-900">{lang.name}</span>
                      </div>
                      <span className="text-gray-600">{lang.percentage}%</span>
                    </div>
                    <Progress value={lang.percentage} className="h-2" />
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Top Repositories */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Top Repositories
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {profileData.topRepos.map((repo) => (
                  <div key={repo.name} className="p-3 rounded-lg border border-gray-200">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="text-gray-900">{repo.name}</h4>
                      <Badge variant="secondary">{repo.language}</Badge>
                    </div>
                    <div className="flex items-center gap-4 text-gray-600">
                      <span className="flex items-center gap-1">
                        <Star className="h-4 w-4" />
                        {repo.stars}
                      </span>
                      <span className="flex items-center gap-1">
                        <GitFork className="h-4 w-4" />
                        {repo.forks}
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Improvement Suggestions */}
          <Card>
            <CardHeader>
              <CardTitle>Recommendations for Improvement</CardTitle>
              <CardDescription>Tips to boost your GitHub score</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {score.breakdown.contributions < 20 && (
                  <div className="p-4 rounded-lg bg-blue-50 border border-blue-200">
                    <h4 className="text-gray-900 mb-2">Increase Contributions</h4>
                    <p className="text-gray-600">Try to contribute more regularly. Aim for a daily commit streak to improve your contribution score.</p>
                  </div>
                )}
                {score.breakdown.stars < 15 && (
                  <div className="p-4 rounded-lg bg-purple-50 border border-purple-200">
                    <h4 className="text-gray-900 mb-2">Build Quality Projects</h4>
                    <p className="text-gray-600">Create useful, well-documented projects that others want to star and contribute to.</p>
                  </div>
                )}
                {score.breakdown.diversity < 12 && (
                  <div className="p-4 rounded-lg bg-green-50 border border-green-200">
                    <h4 className="text-gray-900 mb-2">Learn New Languages</h4>
                    <p className="text-gray-600">Diversify your skill set by learning and using different programming languages in your projects.</p>
                  </div>
                )}
                {score.breakdown.followers < 8 && (
                  <div className="p-4 rounded-lg bg-orange-50 border border-orange-200">
                    <h4 className="text-gray-900 mb-2">Engage with Community</h4>
                    <p className="text-gray-600">Participate in open source, comment on issues, and engage with other developers to grow your network.</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
